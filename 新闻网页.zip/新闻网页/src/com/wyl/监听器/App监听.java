package com.wyl.监听器;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.logging.log4j.LogManager;

import com.wyl.sendMail.取得上下文元素;
import com.wyl.工具.LogUtil;

@WebListener
public class App监听 implements ServletContextListener,ServletContextAttributeListener{

	@Override
	public void attributeAdded(ServletContextAttributeEvent scab) {
	}

	@Override
	public void attributeRemoved(ServletContextAttributeEvent scab) {
	}

	@Override
	public void attributeReplaced(ServletContextAttributeEvent scab) {
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		取得上下文元素.元素=sce.getServletContext();
		LogUtil.logger = LogManager.getLogger(取得上下文元素.元素.getInitParameter("target"));
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}

}
