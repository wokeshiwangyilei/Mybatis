package com.wyl.监听器;

import javax.servlet.annotation.WebListener;

@WebListener
public class Log4j2监听 extends org.apache.logging.log4j.web.Log4jServletContextListener{

}
