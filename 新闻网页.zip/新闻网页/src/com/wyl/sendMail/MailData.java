package com.wyl.sendMail;

public class MailData {
	String 收件人;
	String 内容;

	public String get收件人() {
		return 收件人;
	}

	public void set(String 收件人, String 内容) {
		this.收件人 = 收件人;
		this.内容 = 内容;
	}

	public String get内容() {
		return 内容;
	}

}
