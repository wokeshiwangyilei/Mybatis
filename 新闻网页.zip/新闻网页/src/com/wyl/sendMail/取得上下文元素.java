package com.wyl.sendMail;

import javax.servlet.ServletContext;

public class 取得上下文元素 {
	public static ServletContext 元素;
}
