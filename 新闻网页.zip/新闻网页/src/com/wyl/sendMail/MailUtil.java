package com.wyl.sendMail;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

public class MailUtil {

	public static void send(String 地址, String 内容) throws EmailException {

		HtmlEmail htmlEmail = new HtmlEmail();
		htmlEmail.setCharset("utf-8");
		htmlEmail.setHostName(取得上下文元素.元素.getInitParameter("host").toString());
		htmlEmail.addTo(地址);
		htmlEmail.setFrom(取得上下文元素.元素.getInitParameter("from").toString(),
				取得上下文元素.元素.getInitParameter("from").toString());
		htmlEmail.setSSLOnConnect(Boolean.parseBoolean(取得上下文元素.元素.getInitParameter("ssl").toString()));
		htmlEmail.setAuthentication(取得上下文元素.元素.getInitParameter("from").toString(),
				取得上下文元素.元素.getInitParameter("pwd").toString());
		htmlEmail.setSubject("注册验证");
		htmlEmail.setMsg("请点击下面的链接进行验证<hr><a href='http://192.168.60.151:8080/a/sendonemail" + 内容 + "'>请点击这里</a>");
		htmlEmail.send();
		
	}
}
