package com.wyl.工具;

import org.apache.commons.codec.digest.DigestUtils;

public class 编码工具 {
	public static String MD5(String src) {

		return DigestUtils.md5Hex(src);
	}
}
