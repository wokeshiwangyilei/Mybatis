package com.wyl.工具;

import java.util.UUID;

public class 随机码 {

	public static String get() {
		return UUID.randomUUID().toString().replace("-", "");
	}
}
