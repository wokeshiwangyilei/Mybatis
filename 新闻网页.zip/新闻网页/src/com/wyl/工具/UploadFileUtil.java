package com.wyl.工具;

import java.io.File;
import java.util.Date;
import javax.servlet.http.Part;

import net.coobird.thumbnailator.Thumbnails;

public class UploadFileUtil {
	public static String up(String 根目录, Part part) throws Exception {

		String fileExtension = part.getHeader("Content-Type");
		String fileName = new Date().getTime() + "";

		if (fileExtension.equalsIgnoreCase("image/tiff")) {
			fileName += ".tif";
		}
		if (fileExtension.equalsIgnoreCase("image/fax")) {
			fileName += ".fax";
		}
		if (fileExtension.equalsIgnoreCase("image/gif")) {
			fileName += ".gif";
		}
		if (fileExtension.equalsIgnoreCase("image/x-icon")) {
			fileName += ".ico";
		}
		if (fileExtension.equalsIgnoreCase("image/jpeg")) {
			fileName += ".jpg";
		}
		if (fileExtension.equalsIgnoreCase("image/pnetvue")) {
			fileName += ".net";
		}
		if (fileExtension.equalsIgnoreCase("image/png")) {
			fileName += ".png";
		}
		if (fileExtension.equalsIgnoreCase("image/vnd.rn-realpix")) {
			fileName += ".rp";
		}
		if (fileExtension.equalsIgnoreCase("image/vnd.wap.wbmp")) {
			fileName += ".wbmp";
		}

		if (fileExtension.equalsIgnoreCase("image/bmp")) {
			fileName += ".bmp";
		}

		part.write(根目录 + File.separator + fileName);

		// 压缩A
		Thumbnails.of(根目录 + File.separator + fileName).forceSize(640, 426)
				.toFile(根目录 + File.separator + "A" + fileName);
		// 压缩B
		Thumbnails.of(根目录 + File.separator + fileName).forceSize(240, 170)
				.toFile(根目录 + File.separator + "B" + fileName);
		// 压缩C
		Thumbnails.of(根目录 + File.separator + fileName).forceSize(134, 90).toFile(根目录 + File.separator + "C" + fileName);
		
		File file = new File(根目录 + File.separator + fileName);
		if (file.exists()) {
			file.delete();
		}
		// 返回原始文件名
		return fileName;
	}

}
