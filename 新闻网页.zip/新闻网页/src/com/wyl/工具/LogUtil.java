package com.wyl.工具;

import org.apache.logging.log4j.Logger;

public class LogUtil {
	public static Logger logger;

	public static void log(String 消息) {
		logger.debug(消息);
	}
}
