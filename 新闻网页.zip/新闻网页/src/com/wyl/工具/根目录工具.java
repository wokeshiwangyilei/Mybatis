package com.wyl.工具;

import javax.servlet.http.HttpServletRequest;

public class 根目录工具 {
	
	public static String 项目根目录(HttpServletRequest req){
		String path = req.getContextPath();
		String basePath = req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+path+"/";
		return basePath;
	}
	public static String 项目根目录外加url(HttpServletRequest req,String url){
		String path = req.getContextPath();
		String basePath = req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+path+"/"+url;
		return basePath;
	}
}
