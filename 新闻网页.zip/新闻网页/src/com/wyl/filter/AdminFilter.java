package com.wyl.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.工具.根目录工具;

@WebFilter(filterName = "F002", urlPatterns = { "/admin/*" })
public class AdminFilter implements Filter{

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpServletRequest=(HttpServletRequest) request;
		HttpServletResponse httpServletResponse=(HttpServletResponse) response;
		httpServletRequest.setCharacterEncoding("utf-8");
		httpServletResponse.setContentType("text/html;charset=UTF-8");
		Object object=httpServletRequest.getSession().getAttribute("Admin");
		if (object!=null) {
			chain.doFilter(httpServletRequest, httpServletResponse);
		}else {
			httpServletResponse.sendRedirect(根目录工具.项目根目录外加url(httpServletRequest, "index.jsp"));
		}
	}

	@Override
	public void destroy() {
	}

}
