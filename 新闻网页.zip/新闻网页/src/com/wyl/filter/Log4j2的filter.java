package com.wyl.filter;

import javax.servlet.DispatcherType;
import javax.servlet.annotation.WebFilter;

@WebFilter(filterName = "F001",
		urlPatterns = "/*", 
		dispatcherTypes = { 
		DispatcherType.ASYNC,
		DispatcherType.ERROR, 
		DispatcherType.FORWARD, 
		DispatcherType.REQUEST, 
		DispatcherType.INCLUDE })
public class Log4j2的filter extends org.apache.logging.log4j.web.Log4jServletFilter {

}
