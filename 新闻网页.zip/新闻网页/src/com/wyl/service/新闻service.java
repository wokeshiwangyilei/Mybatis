package com.wyl.service;

import java.io.File;
import java.util.ArrayList;

import javax.servlet.http.Part;

import org.apache.ibatis.session.SqlSession;

import com.wyl.beans.News;
import com.wyl.beans.NewsInfo;
import com.wyl.beans.NewsQuery;
import com.wyl.dao.NewsInfoMapper;
import com.wyl.dao.NewsMapper;
import com.wyl.sendMail.取得上下文元素;
import com.wyl.工具.SQL;
import com.wyl.工具.UploadFileUtil;

public class 新闻service {
	String savePath = 取得上下文元素.元素.getRealPath("/img");

	public ArrayList<News> Allnews() throws Exception {
		SqlSession session = SQL.get().openSession();

		NewsMapper mapper = session.getMapper(NewsMapper.class);
		ArrayList<News> arrayList = (ArrayList<News>) mapper.selectByExample();

		session.close();
		return arrayList;
	}

	public boolean 删除(int i) throws Exception {
		boolean a = false;
		SqlSession session = SQL.get().openSession(false);
		NewsMapper 新闻mapper = session.getMapper(NewsMapper.class);
		NewsInfoMapper newsInfoMapper = session.getMapper(NewsInfoMapper.class);	
		News news = 通过id查询(i);
		
		int w = 新闻mapper.deleteByPrimaryKey(i);
		if (w > 0) {
			int w2=newsInfoMapper.deleteByPrimaryKey(i);
			if (w2>0) {
				
				String fA = savePath + File.separator + news.getPhotoA();
				String fB = savePath + File.separator + news.getPhotoB();
				String fC = savePath + File.separator + news.getPhotoC();
				
				File fileA = new File(fA);
				File fileB = new File(fB);
				File fileC = new File(fC);
				
				if (fileA.exists()) {
					fileA.delete();
				}
				if (fileB.exists()) {
					fileB.delete();
				}
				if (fileC.exists()) {
					fileC.delete();
				}
				
				a = true;
				session.commit();
				
				
			}else {
				throw new Exception("新闻内容删除失败,出错啦啦啦啦啦啦");
			}
		} else {
			throw new Exception("新闻删除失败,出错啦啦啦啦啦啦");
		}
		session.close();
		return a;

	}

	public boolean add(News news, NewsInfo newsInfo, Part part) throws Exception {
		boolean l = false;
		SqlSession session = SQL.get().openSession();
		NewsMapper newsMapper = session.getMapper(NewsMapper.class);
		NewsInfoMapper newsInfoMapper = session.getMapper(NewsInfoMapper.class);
		int i = newsMapper.insert(news);

		if (i > 0) {

			newsInfo.setNewsId(news.getId());
			int i2 = newsInfoMapper.insert(newsInfo);
			if (i2 > 0) {
				String photoANewFileName = UploadFileUtil.up(savePath, part);

				news.setPhotoA("A" + photoANewFileName);
				news.setPhotoB("B" + photoANewFileName);
				news.setPhotoC("C" + photoANewFileName);
				int i3 = newsMapper.更新图片(news);
				if (i3 > 0) {
					l = true;
					session.commit();

				} else {
					throw new Exception("无法更换图片");
				}

			} else {
				throw new Exception("无法添加新闻内容");
			}
		} else {
			throw new Exception("无法添加新闻基本信息");
		}
		session.close();
		return l;
	}

	public ArrayList<News> Query查询(NewsQuery newsQuery) throws Exception {

		SqlSession session = SQL.get().openSession();
		NewsMapper newsMapper = session.getMapper(NewsMapper.class);
		ArrayList<News> arrayList = newsMapper.组合查询(newsQuery);
		session.close();
		return arrayList;
	}

	public News 通过id查询(Integer id) throws Exception {
		SqlSession session = SQL.get().openSession();
		NewsMapper newsMapper = session.getMapper(NewsMapper.class);
		News news = newsMapper.selectByPrimaryKey(id);
		session.close();
		return news;
	}

	public Boolean 设置(News news, NewsInfo newsInfo, boolean isPhoto, Part part) throws Exception {
		boolean b = false;
		SqlSession session=SQL.get().openSession();
		NewsMapper newsMapper=session.getMapper(NewsMapper.class);
		NewsInfoMapper newsInfoMapperewsInfoMapper=session.getMapper(NewsInfoMapper.class);
		
		int t = newsMapper.updateByPrimaryKey(news);
		if (t>0) {
			int t2=newsInfoMapperewsInfoMapper.更新新闻内容(newsInfo);
			if (t2>0) {
				boolean b2=true;
				if (isPhoto) {
					String fA = savePath + File.separator + news.getPhotoA();
					String fB = savePath + File.separator + news.getPhotoB();
					String fC = savePath + File.separator + news.getPhotoC();
					
					File fileA = new File(fA);
					File fileB = new File(fB);
					File fileC = new File(fC);
					
					if (fileA.exists()) {
						fileA.delete();
					}
					if (fileB.exists()) {
						fileB.delete();
					}
					if (fileC.exists()) {
						fileC.delete();
					}
					
					String photoANewFileName = UploadFileUtil.up(savePath, part);
					
					news.setPhotoA("A" + photoANewFileName);
					news.setPhotoB("B" + photoANewFileName);
					news.setPhotoC("C" + photoANewFileName);
					
					int t3 = newsMapper.更新图片(news);
					if (t3<=0) {
						b2=false;
						
					}
				}
				if (b2) {
					b=true;
					session.commit();
				}
			}else {
				throw new Exception("更新新闻内容失败");
			}
		}else {
			throw new Exception("更新新闻失败");
		}session.close();
		
		return b;
	}
}
