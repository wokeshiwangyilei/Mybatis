package com.wyl.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;

import com.wyl.beans.Admin;
import com.wyl.beans.AdminExample;
import com.wyl.beans.AdminExample.Criteria;
import com.wyl.dao.AdminMapper;
import com.wyl.工具.SQL;

public class 管理登陆service {
	public Admin 登陆(Admin 用户) {

		Admin 结果 = null;
		SqlSession session = null;
		try {
			session = SQL.get().openSession();

			AdminMapper a = session.getMapper(AdminMapper.class);

			AdminExample b = new AdminExample();

			Criteria c = b.createCriteria();
			c.andUsernameEqualTo(用户.getUsername()).andPasswordEqualTo(用户.getPassword());

			ArrayList<Admin> admins = (ArrayList<Admin>) a.selectByExample(b);

			if (admins != null && admins.size() > 0) {
				结果 = admins.get(0);
			}
			session.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 结果;
	}


}
