package com.wyl.service;


import org.apache.ibatis.session.SqlSession;

import com.wyl.beans.NewsInfo;
import com.wyl.dao.NewsInfoMapper;
import com.wyl.工具.SQL;

public class 新闻信息service {

	public boolean add(NewsInfo newsInfo) throws Exception {
		boolean a = false;
		SqlSession session = SQL.get().openSession();
		NewsInfoMapper newsInfo2 = session.getMapper(NewsInfoMapper.class);
		int s = newsInfo2.insert(newsInfo);
		if (s > 0) {
			a = true;
			session.commit();
		}
		session.close();

		return a;
	}


	public NewsInfo 通过新闻找(Integer newid) throws Exception {

		SqlSession sqlSession = SQL.get().openSession();
		NewsInfoMapper newsInfoMapper = sqlSession.getMapper(NewsInfoMapper.class);
		NewsInfo result = newsInfoMapper.selectByNews(newid);
		sqlSession.commit();
		sqlSession.close();

		return result;
	}
}
