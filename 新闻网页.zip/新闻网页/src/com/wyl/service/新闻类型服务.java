package com.wyl.service;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;

import com.wyl.beans.NewsType;
import com.wyl.dao.NewsMapper;
import com.wyl.dao.NewsTypeMapper;
import com.wyl.工具.SQL;

public class 新闻类型服务 {
	public ArrayList<NewsType> findByAll() throws Exception {

		ArrayList<NewsType> result;
		SqlSession sqlSession = SQL.get().openSession();
		NewsTypeMapper newsTypeMapper = sqlSession.getMapper(NewsTypeMapper.class);
		result = (ArrayList<NewsType>) newsTypeMapper.selectByExample(null);
		sqlSession.close();
		return result;

	}

	public NewsType findById(Integer id) throws Exception {

		SqlSession sqlSession = SQL.get().openSession();
		NewsTypeMapper newsTypeMapper = sqlSession.getMapper(NewsTypeMapper.class);
		NewsType result = newsTypeMapper.selectByPrimaryKey(id);
		sqlSession.close();
		return result;

	}


	public boolean 添加(NewsType newsType) throws IOException {
		boolean q = false;
		SqlSession session = SQL.get().openSession(false);
		NewsTypeMapper newsTypeMapper = session.getMapper(NewsTypeMapper.class);
		int i = newsTypeMapper.insert(newsType);
		if (i > 0) {
			q = true;
			session.commit();
		} 
		session.close();
		return q;
	}

	public boolean 修改(NewsType newsType) throws Exception {
		boolean q = false;
		SqlSession session = SQL.get().openSession(false);
		NewsTypeMapper newsTypeMapper = session.getMapper(NewsTypeMapper.class);
		int i = newsTypeMapper.updateByPrimaryKey(newsType);
		if (i > 0) {
			session.commit();
			q = true;
		} else {
			throw new Exception("啊偶,出错了,我也不知道哪错,数据库不会改变");
		}
		session.close();
		return q;
	}

	public boolean 删除(int i) throws Exception {
		boolean a = false;
		SqlSession session = SQL.get().openSession(false);
		NewsTypeMapper 新闻类型Mapper = session.getMapper(NewsTypeMapper.class);
		NewsMapper 新闻mapper = session.getMapper(NewsMapper.class);
		NewsType 新闻类型信息 = new NewsType();
		新闻类型信息.setId(i);
		int q = 新闻mapper.selectByTypeCount(新闻类型信息);
		if (q == 0) {
			int w = 新闻类型Mapper.deleteByPrimaryKey(i);
			if (w > 0) {
				a = true;
				session.commit();
			} else {
				throw new Exception("出错啦啦啦啦啦啦");
			}
		} else {
			throw new Exception("新闻类型中有新闻,不可删除");
		}
		session.close();
		return a;

	}
}
