package com.wyl.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.ibatis.session.SqlSession;
import com.wyl.beans.Users;
import com.wyl.dao.UsersMapper;
import com.wyl.sendMail.MailUtil;
import com.wyl.工具.LogUtil;
import com.wyl.工具.SQL;
import com.wyl.工具.随机码;

public class 用户service {
	int L = 1000 * 60 * 60 * 2;

	public Users Login(Users login) throws IOException {
		Users b = null;
		SqlSession session = SQL.get().openSession(false);
		UsersMapper loginMapper = session.getMapper(UsersMapper.class);
		ArrayList<Users> list = loginMapper.搜索用户名密码(login);

		if (list == null || list.size() == 0) {

		} else {
			int a = list.get(0).getState();
			if (a == 0) {
				Long time = new Date().getTime() - Long.parseLong(list.get(0).getSt());

				if (time > L) {
					loginMapper.deleteByPrimaryKey(list.get(0).getId());
					LogUtil.log(list.get(0).getUsername() + "已超时");
				}

			} else {
				b = list.get(0);
			}
		}
		session.commit();
		session.close();
		return b;

	}

	public boolean write(Users 信息) {
		boolean b = false;

		SqlSession session = null;
		try {
			session = SQL.get().openSession(false);

			UsersMapper usersMapper = session.getMapper(UsersMapper.class);
			信息.setSt(String.valueOf(new Date().getTime()));
			信息.setState(0);
			信息.setVerification(随机码.get());
			信息.setNick(信息.getUsername());
			信息.setPhoto("null");
			int i = usersMapper.insert(信息);

			if (i > 0) {
				String yxString = 信息.getEmail();
				String yxString2 = "?a=" + yxString + "&b=" + 信息.getVerification();
				try {
					MailUtil.send(yxString, yxString2);
				} catch (Exception e) {
					e.printStackTrace();
				}
				LogUtil.log(yxString + "已经发送激活码");

				b = true;
				session.commit();
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		session.close();
		return b;

	}

	public boolean ok否(String 邮箱, String 随机码) throws IOException {

		boolean v = false;
		SqlSession session = SQL.get().openSession(false);
		UsersMapper usersMapper = session.getMapper(UsersMapper.class);
		int i = usersMapper.updatestat(new Users(1, 邮箱, 随机码));
		if (i > 0) {
			v = true;
		} else {
			v = false;
		}
		session.commit();
		session.close();
		return v;
	}

	public boolean 检测邮箱(Users 信息) throws IOException {
		boolean v = false;

		SqlSession session;

		session = SQL.get().openSession();

		UsersMapper usersMapper = session.getMapper(UsersMapper.class);

		ArrayList<Users> list = usersMapper.selectByEmail(信息);

		if (list != null && list.size() > 0) {
			v = false;
		} else {
			v = true;

		}

		return v;
	}

	public boolean 检测用户名(Users 信息) throws IOException {
		boolean v = false;

		SqlSession session;

		session = SQL.get().openSession();

		UsersMapper usersMapper = session.getMapper(UsersMapper.class);

		ArrayList<Users> list = usersMapper.selectBy用户名(信息);

		if (list != null && list.size() > 0) {
			v = false;
		} else {
			v = true;

		}

		return v;
	}
}
