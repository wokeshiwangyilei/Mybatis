package com.wyl.dao;

import com.wyl.beans.NewsInfo;
import java.util.List;

public interface NewsInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewsInfo record);

    List<NewsInfo> selectByExample();

    NewsInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(NewsInfo record);

    
	NewsInfo selectByNews(Integer newid);

	int 更新新闻内容(NewsInfo newsInfo);
    
    
}