package com.wyl.dao;

import com.wyl.beans.News;
import com.wyl.beans.NewsQuery;
import com.wyl.beans.NewsType;

import java.util.ArrayList;
import java.util.List;

public interface NewsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(News record);

   List<News> selectByExample();
    
    List<News> selectByType(NewsType newsType);

    News selectByPrimaryKey(Integer id);

    int selectByTypeCount(NewsType newsType);
    
    int updateByPrimaryKey(News record);

	int 更新图片(News news);

	ArrayList<News> 组合查询(NewsQuery newsQuery);
}