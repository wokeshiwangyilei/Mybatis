package com.wyl.dao;

import java.util.ArrayList;

import com.wyl.beans.Users;

public interface UsersMapper {
	/**/ int deleteByPrimaryKey(Integer id);

	/**/ int insert(Users record);

	/**/ ArrayList<Users> selectByEmail(Users users);

	/**/ ArrayList<Users> selectBy用户名(Users users);

	/**/ int updatestat(Users a);

	int updateByPrimaryKey(Users record);

	/**/ ArrayList<Users> 搜索用户名密码(Users login);
}