package com.wyl.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.News;
import com.wyl.service.新闻service;

@SuppressWarnings("serial")
@WebServlet(name="AllNewsServlet",urlPatterns={"/newservlet.action"})
public class 用户新闻展示servlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻service news=new 新闻service();
		try {
			ArrayList<News> arrayList=news.Allnews();
			req.setAttribute("news", arrayList);
			req.getRequestDispatcher("news.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
