package com.wyl.servlet;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.wyl.beans.Mess;
import com.wyl.beans.News;
import com.wyl.beans.NewsQuery;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻service;
import com.wyl.service.新闻类型服务;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "adminnewsquery", urlPatterns = { "/admin/newsqueryservlet.action" })
public class 管理新闻Queryservlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		NewsQuery newsQuery = new NewsQuery();

		String title = req.getParameter("title");
		String stStart = req.getParameter("stStart");
		String stEnd = req.getParameter("stEnd");
		String[] select = req.getParameterValues("type");

		if (title != null && title.length() > 0) {
			newsQuery.setTitle(title);
		}
		if (stStart != null && stStart.length() > 0 && stEnd != null && stEnd.length() > 0) {
			newsQuery.setStStart(stStart);
			newsQuery.setStEnd(stEnd);
		}
		if (select != null && select[0] != null) {

			try {

				int temp = Integer.parseInt(select[0]);
				if (temp > 0) {
					newsQuery.setNewsTypeId(temp);
				}
			} catch (Exception e) {
				req.getSession().setAttribute("mess", new Mess("参数错误", 2, "信息有误"));
				req.getSession().setAttribute("url", "newservlet.action");
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
			}
		}

		新闻service n新闻service = new 新闻service();
		新闻类型服务 s新闻类型服务 = new 新闻类型服务();
		try {
			ArrayList<NewsType> newsTypes = s新闻类型服务.findByAll();
			ArrayList<News> news = n新闻service.Query查询(newsQuery);
		
			req.setAttribute("news", news);
			req.setAttribute("newsTypes", newsTypes);
			req.getSession().setAttribute("menu", 2);
			req.getRequestDispatcher("newsSelect.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
