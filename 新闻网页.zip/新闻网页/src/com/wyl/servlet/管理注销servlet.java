package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "AdminOutServlet", urlPatterns = { "/admin/AdminOutServlet.action" })
public class 管理注销servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getSession().removeAttribute("Admin");

		resp.sendRedirect(根目录工具.项目根目录外加url(req, "adminlogin.jsp"));

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
