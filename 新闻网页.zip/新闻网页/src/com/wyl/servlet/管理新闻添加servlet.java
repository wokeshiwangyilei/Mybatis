package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.wyl.beans.Mess;
import com.wyl.beans.News;
import com.wyl.beans.NewsInfo;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻service;
import com.wyl.工具.根目录工具;

@MultipartConfig(maxFileSize = 1024 * 1024 * 20)
@SuppressWarnings("serial")
@WebServlet(name = "adminaddnew", urlPatterns = { "/admin/NewsAddServlet.action" })
public class 管理新闻添加servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// 基本流程
		// 1:收集数据、包含基本数据和上传文件对象Part
		// 2:上传文件为null直接重定向
		// 3:处理业务
		News news = new News();
		NewsType newsType = new NewsType();
		NewsInfo newsInfo = new NewsInfo();
		Part part;

		part = req.getPart("photoA");

		if (part.getSize() == 0) {
			req.getSession().setAttribute("mess", new Mess("请添加图片", 2, "新闻添加"));
			resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
			return;
		}
		String titleString = req.getParameter("title");
		String authorString = req.getParameter("author");
		String binfoString = req.getParameter("binfo");
		String typeString = req.getParameter("type");
		String stString = req.getParameter("st");
		String infoString = req.getParameter("info");

		try {

			newsType.setId(Integer.parseInt(typeString));

			news.setTitle(titleString);
			news.setAuthor(authorString);
			news.setSt(stString);
			news.setStartInfo(binfoString);
			news.setNewsType(newsType);

			newsInfo.setInfo(infoString);

			新闻service n新闻service = new 新闻service();
			if (n新闻service.add(news, newsInfo, part)) {
				req.getSession().setAttribute("mess", new Mess("添加成功", 1, "添加新闻"));
			} else {
				req.getSession().setAttribute("mess", new Mess("添加失败1", 2, "添加新闻"));
			}

		} catch (Exception e) {
			e.getStackTrace();
			req.getSession().setAttribute("mess", new Mess("添加失败" + e.getMessage(), 3, "添加新闻"));
		}
		req.getSession().setAttribute("url", "newservlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
