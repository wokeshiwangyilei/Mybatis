package com.wyl.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.News;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻service;
import com.wyl.service.新闻类型服务;

@SuppressWarnings("serial")
@WebServlet(name = "adminAllNews", urlPatterns = { "/admin/newservlet.action" })
public class 管理新闻展示servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻service news = new 新闻service();
		新闻类型服务 newstype = new 新闻类型服务();
		try {
			ArrayList<News> arrayList = news.Allnews();
			ArrayList<NewsType> nArrayList = newstype.findByAll();
			req.setAttribute("news", arrayList);
			req.setAttribute("newsTypes", nArrayList);
			req.getSession().setAttribute("menu", 2);
			req.getRequestDispatcher("newsSelect.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
