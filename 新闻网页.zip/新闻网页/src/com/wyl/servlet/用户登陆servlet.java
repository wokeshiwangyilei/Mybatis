package com.wyl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.beans.Users;
import com.wyl.service.用户service;
import com.wyl.工具.LogUtil;
import com.wyl.工具.根目录工具;
import com.wyl.工具.编码工具;

@SuppressWarnings("serial")
@WebServlet(name = "登陆servlet", urlPatterns = {"/form/Login"})
public class 用户登陆servlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Users 用户信息 = new Users();
		用户service 登陆service = new 用户service();

		用户信息.setUsername(req.getParameter("b"));
		用户信息.setPassword(编码工具.MD5(req.getParameter("a")));

		Users 扫描结果;

		
		try {
			扫描结果 = 登陆service.Login(用户信息);
			if (扫描结果 != null) {
				
				LogUtil.log(用户信息.getUsername() + "登录成功");
				req.getSession().setAttribute("Users", 用户信息);
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "index.jsp"));
			} else {
				LogUtil.log(用户信息.getUsername() + "||该用户名使用错误密码" + 用户信息.getPassword() + "登陆");
				req.getSession().setAttribute("mess", new Mess("用户名可能未激活,请重新注册"));
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));
			}
		} catch (Exception e) {
			LogUtil.log(用户信息.getUsername() + "||该用户名使用错误密码" + 用户信息.getPassword() + "登陆");
			req.getSession().setAttribute("mess", new Mess("用户名和密码错误"));
			resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));
		}

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doPost(req, resp);
	}

}
