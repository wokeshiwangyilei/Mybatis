package com.wyl.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.NewsType;
import com.wyl.service.新闻类型服务;
@SuppressWarnings("serial")
@WebServlet(name="newsaddservletbefore",urlPatterns="/admin/brfornewadd.action")
public class 管理新闻添加前servlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻类型服务 n新闻类型服务=new 新闻类型服务();
		
		try {
			ArrayList<NewsType>  arrayList = n新闻类型服务.findByAll();
			req.setAttribute("newsType", arrayList);
			req.getRequestDispatcher("newsAdd.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
