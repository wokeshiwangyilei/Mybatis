package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.service.新闻类型服务;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "NewsTypeDelectServlet", urlPatterns = { "/admin/NewsTypeDelServlet.action" })
public class 管理新闻类型删除servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻类型服务 a新闻类型服务 = new 新闻类型服务();
		try {
			int i = Integer.parseInt(req.getParameter("id"));

			if (a新闻类型服务.删除(i)) {
				req.getSession().setAttribute("mess", new Mess("删除成功", 1, "新闻类型删除"));
			} else {
				req.getSession().setAttribute("mess", new Mess("删除失败,未知错误", 2, "新闻类型删除"));
			}
		} catch (Exception e) {
			req.getSession().setAttribute("mess", new Mess("删除失败:" + e.getMessage(), 2, "新闻类型删除"));
		}
		req.getSession().setAttribute("url", "NewsTypeSelectServlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
