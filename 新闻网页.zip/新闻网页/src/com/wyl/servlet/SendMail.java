package com.wyl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.service.用户service;
import com.wyl.工具.LogUtil;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(
		name="发送邮件",
	urlPatterns={"/sendonemail"}
)
public class SendMail extends HttpServlet {


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String yxString = request.getParameter("a");
		String yxString2 = request.getParameter("b");
		
		String messString="";
		
		用户service a验证用户=new 用户service();
		try {
			if (a验证用户.ok否(yxString, yxString2)) {
				LogUtil.log(yxString+"验证成功1"+SendMail.class);
				messString="验证成功";
			}else{
				LogUtil.log(yxString+"验证失败2"+SendMail.class);
				messString="验证失败";
			}
		} catch (Exception e) {
			LogUtil.log(yxString+"验证失败3"+SendMail.class);
			messString="验证失败";
			e.printStackTrace();
		}
	
		request.getSession().setAttribute("mess",new Mess(messString) );
		response.sendRedirect(根目录工具.项目根目录外加url(request,"mess.jsp"));
		
		
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

}
