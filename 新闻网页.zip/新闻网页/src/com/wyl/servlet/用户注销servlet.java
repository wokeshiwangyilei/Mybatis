package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.工具.根目录工具;
@SuppressWarnings("serial")
@WebServlet(name = "Login", urlPatterns = {"/form/unLogin.do"})
public class 用户注销servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(req.getSession().getAttribute("Users")!=null){
			req.getSession().removeAttribute("Users");
		}
		
		resp.sendRedirect(根目录工具.项目根目录外加url(req,"index.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
	}

}
