package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻类型服务;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "NewsTypeAddServlet", urlPatterns = { "/admin/NewsTypeAddServlet.action" })
public class 管理新闻类型添加servlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻类型服务 x=new 新闻类型服务();
		String aString=req.getParameter("name");
		if(aString!=null&&aString.length()>0){
			NewsType newsType=new NewsType();
			newsType.setName(aString);
			try {
				if (x.添加(newsType)) {
					req.getSession().setAttribute("mess", new Mess("添加成功", 1,"新闻类型添加"));
				}else {
					req.getSession().setAttribute("mess", new Mess("添加失败,MySQL错误", 3,"新闻类型添加"));
				}
			} catch (Exception e) {
				e.printStackTrace();
				req.getSession().setAttribute("mess", new Mess("服务器错误", 3,"新闻类型添加"));
			}
		}else {
			req.getSession().setAttribute("mess", new Mess("添加失败", 2,"新闻类型添加"));
		}
		req.getSession().setAttribute("url", "NewsTypeSelectServlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
