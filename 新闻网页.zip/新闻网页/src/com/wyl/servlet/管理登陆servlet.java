package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Admin;
import com.wyl.beans.Mess;
import com.wyl.service.管理登陆service;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "Adminservlet", urlPatterns = "/form/AdminServlet.action")
public class 管理登陆servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		管理登陆service 登陆service = new 管理登陆service();
		String aString = req.getParameter("username");
		String bString = req.getParameter("password");

		try {
			if (aString != null && bString != null) {
				Admin aa = new Admin();
				aa.setPassword(bString);
				aa.setUsername(aString);
				req.getSession().setAttribute("menu", 1);
				Admin 结果 = 登陆service.登陆(aa);
				if (结果 != null) {

					req.getSession().setAttribute("Admin", 结果);
					resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/t.jsp"));
				} else {

					req.getSession().setAttribute("mess", new Mess("用户名密码错误"));
					resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));
				}

			} else {
				req.getSession().setAttribute("mess", new Mess("非法登陆"));
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));

			}
		} catch (Exception e) {
			req.getSession().setAttribute("mess", new Mess("服务器维护中"));
			resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));
			e.getStackTrace();

		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
