package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻类型服务;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "NewsTypeEditServlet", urlPatterns = { "/admin/NewsTypeEditServlet.action" })
public class 管理新闻类型修改servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻类型服务 a = new 新闻类型服务();
		String nameString = req.getParameter("name");
		NewsType newsType = new NewsType();
		try {
			newsType.setId(Integer.parseInt(req.getParameter("id")));
			newsType.setName(nameString);
			if (nameString != null && nameString.length() > 0) {

				if (a.修改(newsType)) {
					req.getSession().setAttribute("mess", new Mess("修改成功",1,"新闻类型修改"));
				}else {
					req.getSession().setAttribute("mess", new Mess("修改失败,未知错误",2,"新闻类型修改"));
				}

			} else {
				req.getSession().setAttribute("mess", new Mess("修改失败,名称不能为空", 2, "新闻类型修改"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		req.getSession().setAttribute("url", "NewsTypeSelectServlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
