package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.beans.News;
import com.wyl.beans.NewsInfo;
import com.wyl.service.新闻service;
import com.wyl.service.新闻信息service;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "NewsInfoSelectServlet", urlPatterns = { "/admin/NewsInfoSelectServlet.action" })
public class 管理新闻信息servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			int i = Integer.parseInt(req.getParameter("id"));
			新闻service a新闻service = new 新闻service();
			新闻信息service a新闻信息service = new 新闻信息service();
			News news = null;
			NewsInfo newsInfo = null;

			news = a新闻service.通过id查询(i);
			newsInfo = a新闻信息service.通过新闻找(i);

			if (news != null && newsInfo != null) {

				req.setAttribute("news", news);
				req.setAttribute("newsInfo", newsInfo);
				req.getRequestDispatcher("newsInfo.jsp").forward(req, resp);

			} else {
				req.getSession().setAttribute("mess", new Mess("新闻内容查询失败", 2, "新闻内容查看"));
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
			}

		} catch (Exception e) {
			e.printStackTrace();
			req.getSession().setAttribute("mess", new Mess("新闻内容查询失败", 2, "新闻内容查看"));
			resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
