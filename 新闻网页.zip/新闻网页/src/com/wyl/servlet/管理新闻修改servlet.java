package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.wyl.beans.Mess;
import com.wyl.beans.News;
import com.wyl.beans.NewsInfo;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻service;
import com.wyl.工具.根目录工具;


@MultipartConfig(maxFileSize = 1024 * 1024 * 20)
@SuppressWarnings("serial")
@WebServlet(name = "edititservlet", urlPatterns = "/admin/NewsEditServlet.action")
public class 管理新闻修改servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
		News news = new News();
		NewsType newsType = new NewsType();
		NewsInfo newsInfo = new NewsInfo();
		Part part;

		String photoAOld = req.getParameter("photoAOld");
		String photoBOld = req.getParameter("photoBOld");
		String photoCOld = req.getParameter("photoCOld");

		news.setPhotoA(photoAOld);
		news.setPhotoB(photoBOld);
		news.setPhotoC(photoCOld);

		boolean isPhoto = req.getParameter("isPhoto") != null ? true : false;

		part = req.getPart("photoA");

		if (isPhoto) {
			// 判断上传图片文本有没有文件
			// part.getSize()为0代表根本没有上传文件
			if (part.getSize() == 0) {
				req.getSession().setAttribute("mess", new Mess("修改失败,没有任何图片上传", 2, "新闻添加"));
				req.getSession().setAttribute("url", "newservlet.action");
				resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
				return;
			}
		}
		
		int id = Integer.parseInt(req.getParameter("id"));
		String title = req.getParameter("title");
		String author = req.getParameter("author");
		String startInfo = req.getParameter("startInfo");
		String st = req.getParameter("st");
		// 新闻类型
		String type = req.getParameter("type");
		// 新闻内容
		String info = req.getParameter("info");
		
		newsType.setId(Integer.parseInt(type));
		
		news.setId(id);
		news.setTitle(title);
		news.setAuthor(author);
		news.setSt(st);
		news.setStartInfo(startInfo);
		news.setNewsType(newsType);

		newsInfo.setNewsId(news.getId());
		newsInfo.setInfo(info);

		新闻service a新闻service = new 新闻service();
		
			if (a新闻service.设置(news, newsInfo, isPhoto, part)) {
				req.getSession().setAttribute("mess", new Mess("新闻编辑成功", 1, "新闻修改"));
			}
			else {
				req.getSession().setAttribute("mess", new Mess("新闻编辑失败11", 2, "新闻编辑"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.getSession().setAttribute("mess", new Mess("新闻编辑失败22", 3, "新闻编辑"));
		}

		req.getSession().setAttribute("url", "newservlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
