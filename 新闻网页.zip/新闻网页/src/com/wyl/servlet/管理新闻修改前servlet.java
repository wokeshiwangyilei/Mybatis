package com.wyl.servlet;

import java.io.IOException;

import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.wyl.beans.Mess;
import com.wyl.beans.News;
import com.wyl.beans.NewsInfo;
import com.wyl.beans.NewsType;
import com.wyl.service.新闻service;
import com.wyl.service.新闻信息service;
import com.wyl.service.新闻类型服务;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "editbefor", urlPatterns = "/admin/NewsEditBeforeServlet.action")
public class 管理新闻修改前servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻service a新闻service = new 新闻service();
		新闻类型服务 a新闻类型服务 = new 新闻类型服务();
		新闻信息service 新闻信息service = new 新闻信息service();
		try {

			int i = Integer.parseInt(req.getParameter("id"));

			ArrayList<NewsType> newsTypes = a新闻类型服务.findByAll();
			News news = a新闻service.通过id查询(i);
			NewsInfo newsInfo = 新闻信息service.通过新闻找(i);

			req.setAttribute("newsTypes", newsTypes);
			req.setAttribute("news", news);
			req.setAttribute("newsInfo", newsInfo);
			req.getRequestDispatcher("newsEdit.jsp").forward(req, resp);
		} catch (Exception e) {
			e.getStackTrace();
			req.getSession().setAttribute("mess", new Mess("新闻编辑失败", 3, "新闻编辑"));
			resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
