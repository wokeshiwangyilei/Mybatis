package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyl.beans.Mess;
import com.wyl.service.新闻service;
import com.wyl.工具.根目录工具;

@SuppressWarnings("serial")
@WebServlet(name = "NewsDelServlet", urlPatterns = { "/admin/NewsDelServlet.action" })
public class 管理新闻删除servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		新闻service a新闻 = new 新闻service();
		try {
			int i = Integer.parseInt(req.getParameter("id"));

			if (a新闻.删除(i) ) {
				req.getSession().setAttribute("mess", new Mess("删除成功", 1, "新闻删除"));
			} else {
				req.getSession().setAttribute("mess", new Mess("删除失败,未知错误", 2, "新闻删除"));
			}
		} catch (Exception e) {
			req.getSession().setAttribute("mess", new Mess("删除失败:" + e.getMessage(), 2, "新闻删除"));
		}
		
		req.getSession().setAttribute("url", "newservlet.action");
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "admin/mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
