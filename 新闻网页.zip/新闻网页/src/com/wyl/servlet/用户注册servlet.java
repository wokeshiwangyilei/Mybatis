package com.wyl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.wyl.beans.Mess;
import com.wyl.beans.Users;
import com.wyl.service.用户service;
import com.wyl.工具.根目录工具;
import com.wyl.工具.编码工具;

@SuppressWarnings("serial")
@WebServlet(name = "用户注册servlet", urlPatterns = "/form/sign")
public class 用户注册servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		用户service 用户注册service = new 用户service();
		Users 信息 = new Users();
		String messString = "";
		信息.setEmail(req.getParameter("userEmail"));
		信息.setPassword(编码工具.MD5(req.getParameter("password")));
		信息.setUsername(req.getParameter("username"));
		try {
			if (用户注册service.检测邮箱(信息)) {

				if (用户注册service.检测用户名(信息)) {

					if (用户注册service.write(信息)) {
						messString = "注册成功,请进入邮箱进行邮箱验证";
					} else {
						messString = "未知错误,请重新注册1";
					}
				} else {
					messString = "用户名重复,请更换用户名";
				}

			} else {
				messString = "注册失败,请更换邮箱注册";
			}

		} catch (Exception e) {
			messString = "注册失败,请重新注册2";
			e.getStackTrace();

		}

		req.getSession().setAttribute("mess", new Mess(messString));
		resp.sendRedirect(根目录工具.项目根目录外加url(req, "mess.jsp"));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
