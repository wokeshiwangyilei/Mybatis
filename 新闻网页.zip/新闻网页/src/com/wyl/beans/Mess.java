package com.wyl.beans;

public class Mess {
	String mesString;
	int stat;
	String otherString;

	public Mess(String mesString, int stat, String otherString) {

		this.mesString = mesString;
		this.stat = stat;
		this.otherString = otherString;
	}

	public String getMesString() {
		return mesString;
	}

	public int getstat() {
		return stat;
	}

	public String getotherString() {
		return otherString;
	}

	public void setMesString(String mesString) {
		this.mesString = mesString;
	}

	public void setstat(int stat) {
		this.stat = stat;
	}

	public void setotherString(String otherString) {
		this.otherString = otherString;
	}

	public Mess(String mesString, String otherString) {
		this.mesString = mesString;
		this.otherString = otherString;
	}

	public Mess(String mesString, int stat) {
		this.mesString = mesString;
		this.stat = stat;
	}

	public Mess(String mesString) {
		this.mesString = mesString;
	}




	

}
