﻿function ss() {
	var inputCode = document.getElementById("input1").value;
	var b = document.getElementById("b").value;
	var c = document.getElementById("a").value;
	if (inputCode.length <= 0) {
		alert("请输入验证码！");
	} else if (inputCode != code2) {
		alert("验证码输入错误！");
		createCode();
	} else if (b.length <= 0) {
		alert("请输入登陆用户名");

	} else if (c.length <= 0) {
		alert("请输入密码");
	} else {

		$('#ff').submit();
	}

}
$(function() {
	createCode();
});

function createCode() {
	var checkCode = document.getElementById("checkCode");
	function RndNum(n) {
		var rnd = "";
		for (var i = 0; i < n; i++)
			rnd += Math.floor(Math.random() * 20);
		return rnd;
	}

	var num = RndNum(2);
	var num2 = RndNum(2);

	code = num + num2;
	code2 = code;

	if (checkCode) {
		checkCode.className = "code";
		checkCode.value = code;
	}

}
function log() {
	var inputCode = document.getElementById("input1").value;
	var b = document.getElementById("username").value;
	var c = document.getElementById("password1").value;
	var d = document.getElementById("password2").value;
	var e = document.getElementById("inputEmail").value;
	var myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;

	if (inputCode.length <= 0) {
		alert("请输入验证码！");
	} else if (inputCode != code2) {
		alert("验证码输入错误！");
		createCode();
	} else if (e.length <= 0) {
		alert("请输入邮箱");
	} else if (!myreg.test(e)) {
		alert("请输入正确邮箱地址");
	} else if (b.length <= 0) {
		alert("请输入登陆用户名");
	} else if (c.length <= 0) {
		alert("请输入密码");
	} else if (d.length <= 0) {
		alert("请再次输入密码");
	} else if (d != c) {
		alert("两次密码不一致");
	} else {

		$('#ff').submit();
	}

}
